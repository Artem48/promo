create trigger delete_user
  before DELETE
  on users
  for each row
  BEGIN
  UPDATE `promcodes` SET userID='1' WHERE `promcodes`.`userID`=OLD.`id`;
  DELETE FROM `prom`.`feedback` WHERE `feedback`.ownerID=OLD.`id` or `feedback`.entityID=OLD.`id`;
END;

