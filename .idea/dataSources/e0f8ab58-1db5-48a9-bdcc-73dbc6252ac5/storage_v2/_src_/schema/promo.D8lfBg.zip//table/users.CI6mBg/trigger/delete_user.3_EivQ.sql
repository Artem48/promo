create trigger delete_user
  before DELETE
  on users
  for each row
  BEGIN
  UPDATE `promocodes` SET userID='1' WHERE `promocodes`.`userID`=OLD.`id`;
  DELETE FROM `promo`.`feedback` WHERE `feedback`.ownerID=OLD.`id` or `feedback`.entityID=OLD.`id`;
END;

