create trigger addPromoDislike
  before INSERT
  on promodislikes
  for each row
  BEGIN
  DELETE FROM `promo`.`promolikes` WHERE `promolikes`.userID=NEW.userID;
END;

