create trigger addShopLike
  before INSERT
  on shoplikes
  for each row
  BEGIN
  DELETE FROM `promo`.`shopdislikes` WHERE `shopdislikes`.userID=NEW.userID;
END;

