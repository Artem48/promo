create trigger addPromoLike
  before INSERT
  on promolikes
  for each row
  BEGIN
  DELETE FROM `promo`.`promodislikes` WHERE `promodislikes`.userID=NEW.userID;
END;

