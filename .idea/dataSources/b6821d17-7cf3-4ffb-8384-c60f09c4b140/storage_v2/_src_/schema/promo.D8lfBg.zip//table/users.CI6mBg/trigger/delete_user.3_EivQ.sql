create trigger delete_user
  before DELETE
  on users
  for each row
  BEGIN
  UPDATE `promocodes` SET userID='1' WHERE `promocodes`.`userID`=OLD.`id`;
  DELETE FROM `promo`.`promolikes` WHERE `promolikes`.userID=OLD.`id`;
  DELETE FROM `promo`.`promodislikes` WHERE `promodislikes`.userID=OLD.`id`;
  DELETE FROM `promo`.`shoplikes` WHERE `shoplikes`.userID=OLD.`id`;
  DELETE FROM `promo`.`shopdislikes` WHERE `shopdislikes`.userID=OLD.`id`;
END;

