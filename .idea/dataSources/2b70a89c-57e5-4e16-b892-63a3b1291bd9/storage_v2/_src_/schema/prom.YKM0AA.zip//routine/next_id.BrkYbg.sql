create function next_id()
  returns int
  BEGIN
    DECLARE _id INTEGER;
    INSERT sequence (stat) VALUES (1);
    SELECT max(id) INTO _id FROM  sequence WHERE  stat = 1;
    DELETE FROM sequence WHERE stat = 0;
    UPDATE sequence SET stat = 0 WHERE stat = 1;
    RETURN _id;
  END;

