create trigger addShopDislike
  before INSERT
  on shopdislikes
  for each row
  BEGIN
  DELETE FROM `promo`.`shoplikes` WHERE `shoplikes`.userID=NEW.userID;
END;

